#include "Weapon.h"

Weapon::Weapon()
{
	name = "Default";
	maxAmmo = 0;
	ammo = 0;
	range = 0;
	dmg = 0;
}

Weapon::Weapon(string name, int ammo, int range, int dmg)
{
	this->name = name;
	this->maxAmmo = ammo;
	this->ammo = ammo;
	this->range = range;
	this->dmg = dmg;
}

void Weapon::setAmmo(int ammo)
{
	this->ammo = ammo;
}

void Weapon::setRange(int range)
{
	this->range = range;
}

void Weapon::setDmg(int dmg)
{
	this->dmg = dmg;
}
int Weapon::getAmmo()
{
	return ammo;
}
int Weapon::getMaxAmmo()
{
	return maxAmmo;
}
int Weapon::getRange()
{
	return range;
}
int Weapon::getDmg()
{
	return dmg;
}
string Weapon::getName()
{
	return name;
}