#include <iostream> 
#include <conio.h>
#include "game.h"
#include "player.h"

using namespace std;

int main()
{
	Game game;
	game.startGame();
	game.loadLevel();
	game.playGame();

	return 0;
}
