#ifndef HEALTHPACK_H
#define HEALTHPACK_H

#include "player.h"
#include "Item.h"

class HealthPack : public Item
{
public:
	HealthPack(string name, int numItems, int id, int healAmount);
	virtual void useItem(Character p1);
	
private:
	int healAmount;
};
#endif