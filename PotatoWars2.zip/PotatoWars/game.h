#ifndef GAME_H
#define GAME_H
#include "Map.h"
#include "display.h"
#include "player.h"
#include "keyboard.h"
#include "Weapon.h"
#include "Bullet.h"
#include "Bot.h"
#include "Inventory.h"
#include "Ammo.h"
#include "HealthPack.h"
#include "Armor.h"
#include <windows.h>
#include <string>
#include <time.h>


class Game
{
public:
	Game();
	void startGame();
	void loadLevel();
	void playGame();
	bool collision(int x, int y, Inventory&, Player& p1, Bot& b1);
	void attack(Player&, Bot&);
private:
	enum mode {EASY, MEDIUM, HARD};
	enum lvl {ROCK = 1, GRASS, ISLAND, SNOW};
	Map map;
	Display display;
	KeyBoard keyboard;
	Player player;
	Bot monster;
	int Y;
	int X;
	int lvlSel;
	bool pickUp;
};
#endif