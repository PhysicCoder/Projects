#ifndef BULLET_H
#define BULLET_H

#include <list>	
#include <iostream>

using namespace std;

class Bullet
{
public:
	Bullet(int id, int dmg, int range, int dir, int x, int y);
	int getID();
	void setID(int id);
	int getPosX();
	int getPosY();
	void setPosition(int x, int y);
	int getDmg();
	int getRange();
	int getDir();
	void setDirection(int dir);
private:
	int x;
	int y;
	int dmg;
	int range;
	int dir;
	int ID;
};

#endif