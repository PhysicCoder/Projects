#ifndef DISPLAY_H
#define DISPLAY_H
#include <iostream>
#include <windows.h>
#include "keyBoard.h"
#include "Map.h"
#include <iomanip>
#include <string>
#include <conio.h>
#include "player.h"
#include "inventory.h"
#include "bot.h"
using namespace std;

class Display
{
public:
	Display();
	void reset();
	void displayMenu();
	void characterMenu();
	void specialopInfo();
	void sniperInfo();
	void assualtInfo();
	void supportInfo();
	void medicInfo();
	void engineerInfo();
	void anti_tankInfo();
	void difficultyMenu();
	void botNumMenu();
	void mapMenu();
	void inventoryMenu(Player& p1, Inventory& I);
	void mapInfo(int map_number);
	void displayScreen(int x, int y, Player&, Inventory&);
	void centerConsoleCursor(int x, int y);
	void clearConsoleScreen(int x, int y);
	void setConsoleSize();
	void setConsoleTextSize(int, int);
	void setConsoleColors(WORD, WORD);
	void setConsoleColor(WORD);
	void checkMap(int x, int y, int map_number);
	void displayBattleScreen(int x, int y, Player&, Bot&);
	int  getBotNum();
	int	 getLvlNum();
	int	 getCharacterNum();
	int  getDifficultyNum();
	int  getKeyStroke();
	bool getStart();
	void getBackground(int);
	Player getPlayer();

private:
	const static WORD EMPTY = 0x0000;
	const static WORD BLOOD = 0x0004;
	const static WORD DEEP_WATER = 0x0001;
	const static WORD LEAF = 0x0002;
	const static WORD CYAN = 0x0003;
    const static WORD PURPLE = 0x0005;
	const static WORD BROWN = 0x0006;
	const static WORD WHITE = 0x0007;
	const static WORD INTENSE = 0x0008;
	const static WORD WATER = 0x0009;
	const static WORD GRASS = 0x000a;
	const static WORD AQUA = 0x000b;
	const static WORD RED = 0x000c;
	const static WORD PINK = 0x000d;
	const static WORD YELLOW = 0x000e;
	const static WORD WHITE_2 = 0x000f;
	const static WORD B_DEEPWATER = 0x0010; // till 20
	const static WORD B_LEAF = 0x0020;
	const static WORD B_CYAN = 0x0030;
	const static WORD B_PURPLE = 0x030;
	const static WORD B_BROWN = 0x0060;
	const static WORD B_WHITE = 0x0070;
	const static WORD B_INTENSE = 0x0080;
	const static WORD B_WATER = 0x0090;
	const static WORD B_GRASS = 0x00a0;
	const static WORD B_AQUA = 0x00b0;
	const static WORD B_RED = 0x00c0;
	const static WORD B_PINK = 0x00d0;
	const static WORD B_YELLOW = 0x00e0;
	const static WORD B_WHITE_2 = 0x00f0;
	const static WORD GREY_BROWN = 0x0068;
	const static WORD BROWN_GREY = 0x0086;
	const static WORD REVERSE = 0x4000;

	void  setTree();
	void  setRock();
	void  setGrass();
	void  setSnow();
	void  setWater();
	void  setDirt();
	void  setHero();
	void  setZombie();
	void  setMonster();
	void  setDeamon();
	void  setBullet();
	void  setHealth_Symbol();
	void  setArmor_Symbol();
	void  setPistol();
	void  setRifle();
	void  setMachineGun();
	void  setMiniGun();
	void  setShotgun();
	void  setAmmo_Symbol();
	void setHud(Player& p1, Inventory& i);

	char tree[7][11];
	char rock[7][11];
	char grass[7][11];
	char snow[7][11];
	char water[7][11];
	char dirt[7][11];
	char hero[7][11];
	char zombie[7][11];
	char monster[7][11];
	char deamon[7][11];
	char health[7][11];
	char armor[7][11];
	char pistol[7][11];
	char weapon[7][11];
	char ammo[7][11];
	char bullet[7][11];

	char A, B, C, D, E, F, G;
	const static char RIGHT_ARROW = 16;
	KeyBoard keyboard;
	Map map;
	int butNum;
	bool start;
	int	charNum;
	int field;
	int keyStroke;
	int backgroundNum;
	int lvlSel;
	string place;
};

#endif