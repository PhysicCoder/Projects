#include "Ammo.h"

Ammo::Ammo(string name, int numItems, int id, int ammoRefill) : Item(name, numItems, id)
{
	this->ammoRefill = ammoRefill;
}
void Ammo::useItem(Character c1)
{
	//checks if the ammoRefill amount + your current ammo will be higher then your maxAmmo
	//if so it sets your ammo to your maxAmmo
	if (c1.getCurWep().getAmmo() + ammoRefill > c1.getCurWep().getMaxAmmo())
		c1.getCurWep().setAmmo(c1.getCurWep().getMaxAmmo());
	//else add the ammoRefill amount to current ammo
	else
		c1.getCurWep().setAmmo(c1.getCurWep().getAmmo() + ammoRefill);

	numItems--;
}