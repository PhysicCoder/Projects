#ifndef BOT_H
#define BOT_H
#include "Character.h"
#include "Weapon.h"
#include "player.h"

class Bot : public Character
{
public:
		Bot();
		Bot(string name, Weapon primeWep, int dmg, int armor, int x, int y);
		void action();
		void defend();
		void seek();
		void stay();
		void sight();
private:
		bool roaming;
		bool staying;
		bool defending;
		bool attacking;
		bool seeking;
		bool vision;
};
#endif