#include "player.h"

Player::Player() {}
Player::Player(string name, Weapon primWep, int dmg, int armor, int x, int y)
{
	this->name = name;
	this->primWep = primWep;
	this->armor = armor;
	this->dmg = dmg;
	this->x = x;
	this->y = y;
}

