#ifndef INVENTORY_H
#define INVENTORY_H
#include <iostream>
#include <list>	
#include "Item.h"

class Inventory
{
public:
	Inventory();
	~Inventory(); //D estructor deletes all items in the inventory
	void addItem(Item* item); // adds an item to the list
	void removeItem(int id); // pass in the id of the item and you can remove it
	void checkNumItems(); // Checks if you have 0 or less of any item and if so it is removed from the list.
	void useItem(string itemName, Character c1); // pass the name of the item and the character into the use item function and you will use that item
	int findItem(string name); // Checks if the name passes is in the list if it is 1 is returned els 0 is returned
	Item& getItem(string name); // Returns an item if it is in the list
	list<Item*>& getInventory(); // returns the inventory list
	int getNextId(); // returns the nextId
private:
	list<Item*> inventory; // inventory list
	list<Item*>::iterator inventoryIter; // invetnory list iterator
	int nextId; // id for the next item put into the list
};
#endif