#ifndef CHARACTER_H
#define CHARACTER_H

#include <string>
#include <list>	
#include "Weapon.h"
#include "Bullet.h"

using namespace std;

class Character
{
public:

	Character();
	Character(string name, Weapon primWep, int dmg, int armor, int x, int y);
	Character::~Character();
	int getPosX();
	int getPosY();
	void setPosition(int x, int y);
	int getDirection();
	void setDiection(int direction);
	void setName(string name);
	string getName();
	Weapon& getPrimWep();
	Weapon& getSecWep();
	Weapon& getVehWep();
	Weapon& getCurWep();
	void changeWep();
	int getDmg();
	int getMaxArmor();
	int getArmor();
	void setArmor(int armor);
	int getmaxHp();
	int getCurHp();
	void setCurHp(int hp);
	void shoot();
	//Vehicle getVehicle();
	void setStatus(bool status);
	bool getStatus();
	bool getDriving();

protected:

	list<Bullet*> bullets; // A list of bullet pointers
	list<Bullet*>::iterator bulletsIter; // An itereator for the Bullet* list
	string name;
	Weapon primWep;
	Weapon secWep;
	Weapon vehWep;
	Weapon curWep;
	int dmg;
	int maxArmor;
	int armor;
	const static int maxHp = 100;
	int curHp;
	int x;
	int y;
	int direction;
	enum dir{N, NE, E, SE, S, SW, W, NW};
	bool shooting;
	bool driving;
	bool status;
	int bulletID;
	//Vehicle vehicle;

};

#endif




