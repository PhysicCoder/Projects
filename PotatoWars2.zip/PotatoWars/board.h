#ifndef MAP_H
#define MAP_H

class Map
{
public:
	Map();
	void map_1();
	void updateMap_1(int, int, int);
	int getMap_1(int, int);
private:
	int map1[32][32];
};

#endif