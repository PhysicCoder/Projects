#include "HealthPack.h"

HealthPack::HealthPack(string name, int numItems, int id, int healAmount) : Item(name, numItems, id)
{
	this->healAmount = healAmount;
}
void HealthPack::useItem(Character c1)
{
	//checks if the heal amount + your current hp will be higher then your maxHp
	//if so it sets your hp to your maxHp
	if (c1.getCurHp() + healAmount > c1.getmaxHp())
		c1.setCurHp(c1.getmaxHp());
	//else add the heal amount to current hp
	else
		c1.setCurHp(c1.getCurHp() + healAmount);

	numItems--;
}