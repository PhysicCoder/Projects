#ifndef ITEM_H
#define ITEM_H

#include "player.h"
#include <string>

using namespace std;

class Item
{
public:
	Item(string name, int numItems, int id);
	string getName();
	int getNumItems();
	int getId();
	void setNumItems(int numItems);
	virtual void useItem(Character p1) = 0;
protected:
	string name;
	int id;
	int numItems; // stores the amount of the item you have
};
#endif