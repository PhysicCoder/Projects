#include "Armor.h"

Armor::Armor(string name, int numItems, int id, int armor) : Item(name, numItems, id)
{
	this->armor = armor;
}
void Armor::useItem(Character c1)
{
	//checks if the heal amount + your current hp will be higher then your maxHp
	//if so it sets your hp to your maxHp
	if (c1.getArmor() + armor > c1.getMaxArmor())
		c1.setArmor(c1.getMaxArmor());
	//else add the heal amount to current hp
	else
		c1.setArmor(c1.getArmor() + armor);

	numItems--;
}