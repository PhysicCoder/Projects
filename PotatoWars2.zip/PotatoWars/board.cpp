#include "board.h"

Map::Map()
{
}

void Map::map_1()
{
	for(int y = 0; y < 32; y++)
	{
		for(int x = 0; x < 32; x++)
		{
			map1[x][y] = 1;
		}
	}
}

void Map::updateMap_1(int x, int y, int obj)
{
	map1[x][y] = obj;
}

int Map::getMap_1(int x, int y)
{
	return map1[x][y];
}