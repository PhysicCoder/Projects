#ifndef PLAYER_H
#define PLAYER_H
#include "keyBoard.h"
#include "character.h"
#include "Weapon.h"
#include <windows.h>

class Player : public Character
{
public:
	Player();
	Player(string name, Weapon primWep, int armor, int dmg, int x, int y);
};

#endif