#ifndef KEYBOARD_H
#define KEYBOARD_H

#include <conio.h>
#include <windows.h>

class KeyBoard
{
public:
	KeyBoard();
	void listen();
	int getPressed();
	const static int KEY_UP = 72;
	const static int KEY_DOWN = 80;
	const static int KEY_LEFT = 75;
	const static int KEY_RIGHT = 77;
	const static int KEY_ESC = 27;
	const static int KEY_SPACE_BAR = 32;
	const static int KEY_ENTER = 13;
	const static int KEY_A = 97;
	const static int KEY_S = 115;
	const static int KEY_W = 119;
	const static int KEY_D = 100;
	const static int KEY_I = 105;
	const static int KEY_H = 104;
private:
	int keyPressed;
};
#endif