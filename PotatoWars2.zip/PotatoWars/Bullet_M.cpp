#include "Bullet.h"

Bullet::Bullet(int id, int dmg, int range, int dir, int x, int y)
{
	ID = id;
	this->dmg = dmg;
	this->range = range;
	this->dir = dir;
	/*Sets the bullets initial potion the the square directly ahead of where the character
	Is facing*/
	switch (dir)
	{
	//n
	case 1:
		this->x = x;
		this->y = y+1;
		break;
	//ne
	case 2:
		this->x = x+1;
		this->y = y+1;
		break;
	//e
	case 3:
		this->x = x+1;
		this->y = y;
		break;
	//se
	case 4:
		this->x = x+1;
		this->y = y-1;
		break;
	//s
	case 5:
		this->x = x;
		this->y = y-1;
		break;
	//sw
	case 6:
		this->x = x-1;
		this->y = y-1;
		break;
	//w
	case 7:
		this->x = x-1;
		this->y = y;
		break;
	//nw
	case 8:
		this->x = x-1;
		this->y = y+1;
		break;
	}
}
int Bullet::getID()
{
	return ID;
}
void Bullet::setID(int id)
{
	ID = id;
}
int Bullet::getPosX()
{
	return x;
}
int Bullet::getPosY()
{
	return y;
}
void Bullet::setPosition(int x, int y)
{
	this->x = x;
	this->y = y;
}
int Bullet::getDmg()
{
	return dmg;
}
int Bullet::getRange()
{
	return range;
}
int Bullet::getDir()
{
	return dir;
}
void Bullet::setDirection(int dir)
{
	this->dir = dir;
}
