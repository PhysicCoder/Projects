#include "inventory.h"

Inventory::Inventory()
{
	nextId = 0;  // sets initial nextId value
}

//Destructor deletes all items in the inventory
Inventory::~Inventory()
{
	for(inventoryIter = inventory.begin(); inventoryIter != inventory.end(); inventoryIter++)
	{
		delete *inventoryIter;
	}
}

//adds an item to the list
void Inventory::addItem(Item* item)
{
	inventory.push_back(item);
	//increments next Id to be used for the next item
	nextId++;
}

//pass in the id of the item and you can remove it
void Inventory::removeItem(int id)
{
	list<Item*>::iterator inventoryIter; // An itereator for the Bullet* list
	inventoryIter = inventory.begin();
	while(inventoryIter != inventory.end())
	{
		if ((*inventoryIter)->getId() == id)
		{
			delete *inventoryIter;
			inventory.erase(inventoryIter);
			break;
		}
		//prints a message if the student is not found in the vector
		else if ((*inventoryIter) == inventory.back())
		{
			cout << "ID: " << id << " is not in the inventory list" << endl;
			system("pause");
			break;
		}
		else
			 inventoryIter++;
	}
}

//Checks if you have 0 or less of any item and if so it is removed from the list.
void Inventory::checkNumItems()
{
	for(inventoryIter = inventory.begin(); inventoryIter != inventory.end(); inventoryIter++)
	{
		if ((*inventoryIter)->getNumItems() <= 0)
		{
			this->removeItem((*inventoryIter)->getId());
		}
	}
}

//pass the name of the item and the character into the use item function and you will use that item
void Inventory::useItem(string itemName, Character c1)
{
	for(inventoryIter = inventory.begin(); inventoryIter != inventory.end(); inventoryIter++)
	{
		if ((*inventoryIter)->getName() == itemName)
			(*inventoryIter)->useItem(c1);
		else
			cout << (*inventoryIter)->getName() << " is not in the inventory ";
	}
}
//Checks if the name passes is in the list if it is 1 is returned els 0 is returned
int Inventory::findItem(string name)
{
	for(inventoryIter = inventory.begin(); inventoryIter != inventory.end(); inventoryIter++)
	{
		if ((*inventoryIter)->getName() == name)
			return 1;
	}
	return 0;
}

//Returns an item if it is in the list
Item& Inventory::getItem(string name)
{
	for(inventoryIter = inventory.begin(); inventoryIter != inventory.end(); inventoryIter++)
	{
		if ((*inventoryIter)->getName() == name)
			return *(*inventoryIter);
	}
}

//returns the inventory list
list<Item*>& Inventory::getInventory()
{
	return inventory;
}

//Returns the next Id
int Inventory::getNextId()
{
	return nextId;
}

