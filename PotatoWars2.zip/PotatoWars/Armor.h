#ifndef ARMOR_H
#define ARMOR_H

#include "Item.h"
#include "player.h"

class Armor : public Item
{
public:
	Armor(string name, int numItems, int id, int armor);
	virtual void useItem(Character p1);
private:
	int armor;
};
#endif