#ifndef WEAPON_H
#define WEAPON_H

#include <string>

using namespace std;

class Weapon
{
public:
	Weapon();
	Weapon(string name, int ammo, int range, int dmg);
	void setAmmo(int);
	void setRange(int);
	void setDmg(int);
	int getAmmo();
	int getMaxAmmo();
	int getRange();
	int getDmg();
	string getName();


private:
	int ammo;
	int maxAmmo;
	int range;
	int dmg;
	string name;

};

#endif