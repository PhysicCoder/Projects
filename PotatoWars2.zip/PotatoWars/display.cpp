#include "display.h"

Display::Display()
{
	A = RIGHT_ARROW, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0;
	start = false;
}

void Display::reset()
{
	A = RIGHT_ARROW, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0;
}
void Display::displayMenu()
{
	setConsoleColors(WHITE, EMPTY);
	clearConsoleScreen(0, 20);
	
	cout <<
		setw(25) << A << " START\n" << endl <<
		setw(25)<< B << " MAP\n"<< endl << 
		setw(25)<< C << " EXIT\n";

	keyboard.listen();

	switch(keyboard.getPressed())
	{
	case keyboard.KEY_UP:
		if(A != 0)
		{
			A = 0;
			C = RIGHT_ARROW;
		}
		else if(B != 0)
		{
			A = RIGHT_ARROW;
			B = 0;
		}
		else if(C != 0)
		{
			B = RIGHT_ARROW;
			C = 0;
		}
		break;
	case keyboard.KEY_DOWN:
		if(A != 0)
		{
			A = 0;
			B = RIGHT_ARROW;
		}
		else if(B != 0)
		{
			B = 0;
			C = RIGHT_ARROW;
		}
		else if(C != 0)
		{
			C = 0;
			A = RIGHT_ARROW;
		}
		break;

	case keyboard.KEY_ENTER:
		clearConsoleScreen(0, 20);

		if(A != 0)
		{
			reset();
			do
			{
				centerConsoleCursor(char(0), 20);
				characterMenu();
			}while(keyboard.getPressed() != keyboard.KEY_ESC && keyboard.getPressed() != keyboard.KEY_ENTER);
		}
		else if(B != 0)
		{
			reset();
			do
			{
				centerConsoleCursor(char(0), 20);
				mapMenu();
			}while(keyboard.getPressed() != keyboard.KEY_ENTER );
		}
		else if(C != 0)
			exit(0);
		break;
	}
}

void Display::characterMenu()
{

	cout <<
		setw(25)<< A <<  " SPECIAL OPS\n\n" ;

	if(A != 0)
		specialopInfo();
		
		
	keyboard.listen();

	switch(keyboard.getPressed())
	{
	case keyboard.KEY_ESC:
		reset();
		start = false;
		break;
	case keyboard.KEY_ENTER:
		
		reset();
		charNum = 7;
		start = true;
		clearConsoleScreen(0,0);
		
		break;
	}
}

void Display::inventoryMenu(Player& p1, Inventory& I)
{
	do
	{
		setConsoleColors(WHITE_2, EMPTY);
		centerConsoleCursor(0, 40);
	
		char h[65] = {char(205)};
		cout << char(201);
		for(int x = 0; x < 65; x++)
			cout << h;
		cout << char(187) << endl;   
		cout << char(186) << "                    PRESS H for health pack                      " << char(186)<< endl;
		cout << char(186) << "                    PRESS A for armor pack                       " << char(186)<< endl;
		cout << char(186) << "                   --------------------------                    " << char(186)<< endl;
		cout << char(186) << "                                                                 " << char(186)<< endl;
		cout << char(186) << "            PRESS ESC KEY to exit the Inventory Menu             " << char(186)<< endl;
		cout << char(186) << "                                                                 " << char(186)<< endl;
		cout << char(186) << "                                                                 " << char(186)<< endl;
		cout << char(200);
		for(int x = 0; x < 65; x++)
			cout << h;
		cout << char(188);

	
		keyboard.listen();
		switch(keyboard.getPressed())
		{
		case keyboard.KEY_H:
			I.removeItem("healthPack");
			break;
		case keyboard.KEY_A:
			I.getItem("armorPack");
			break;
		}
	}while(keyboard.getPressed() != keyboard.KEY_ESC);
}

void Display::mapMenu()
{
	setConsoleColors(WHITE, EMPTY);
	clearConsoleScreen(0, 20);
	
	cout <<
	    setw(25)<< A <<  " ROCKY\n\n" << //bots and items are not implemented in there
		setw(25)<< B <<  " GRASSY\n\n"<< //bots and items are implemented in there
		setw(25)<< C <<  " WATERY\n\n"<< //bots and items are not implemented in there
		setw(25)<< D <<  " SNOWY\n";     //bots and items are not implemented in there

	keyboard.listen();

	switch(keyboard.getPressed())
	{
	case keyboard.KEY_UP:
		if(A != 0)
		{
			A = 0;
			D = RIGHT_ARROW;
		}
		else if(B != 0)
		{
			A = RIGHT_ARROW;
			B = 0;
		}
		else if(C != 0)
		{
			B = RIGHT_ARROW;
			C = 0;
		}
		else if(D != 0)
		{
			C = RIGHT_ARROW;
			D = 0;
		}
		break;
	case keyboard.KEY_DOWN:
		if(A != 0)
		{
			A = 0;
			B = RIGHT_ARROW;
		}
		else if(B != 0)
		{
			B = 0;
			C = RIGHT_ARROW;
		}
		else if(C != 0)
		{
			C = 0;
			D = RIGHT_ARROW;
		}
		else if(D != 0)
		{
			D = 0;
			A = RIGHT_ARROW;
		}
		break;

	case keyboard.KEY_ENTER:
		clearConsoleScreen(0, 20);

		if(A != 0)
		{
			reset();
			lvlSel = 1;
		}
		else if(B != 0)
		{
			reset();
			lvlSel = 2;
		}
		else if(C != 0)
		{
			reset();
			lvlSel = 3;
		}
		else if(D != 0)
		{
			reset();
			lvlSel = 4;
		}
		break;
	}
}

int Display::getLvlNum()
{
	return lvlSel;
}

void Display::specialopInfo()
{
	clearConsoleScreen(0, 40);
	centerConsoleCursor(0, 40);

	char h[65] = {char(205)};

	cout << char(201);
	for(int x = 0; x < 65; x++)
		cout << h;

	cout << char(187) << endl;
	cout << char(186) << " 100 hp, 25 ap, Machine Gun : 20char(0), pistol 20               " << char(186) << endl;
	cout << char(186) << " Range 14, dmg 10                                                "   << char(186) << endl;
	cout << char(186) << " *BONUS when moving or staying still bots have difficulty        " << char(186) << endl;
	cout << char(186) << " seeing you from range                                           " << char(186) << endl;
	cout << char(186) << " snipers have absolutely no difficulty spotting you              " << char(186) << endl;
	cout << char(186) << " special ops see you from range 18                               " << char(186) << endl;
	cout << char(186) << " plus long range with automatic fire                             "  << char(186) << endl;
	cout << char(200);

	for(int x = 0; x < 65; x++)
		cout << h;

	cout << char(188);
}
void Display::sniperInfo()//not included
{
	clearConsoleScreen(0, 40);
	centerConsoleCursor(0, 40);

	char h[65] = {char(205)};
	cout << char(201);
	for(int x = 0; x < 65; x++)
		cout << h;
	
	cout << char(187) << endl;
	cout << char(186) << " 100 hp, 15 ap, zombie RIFLE : 5char(0), pistol 20               " << char(186) << endl; 
	cout << char(186) << " Range 25, dmg 200                                               " << char(186) << endl;
	cout << char(186) << " *BONUS when staying still bots will have difficulty             " <<char(186)<<endl;
	cout << char(186) << " seeing you from range 8, snipers have difficulty                " <<char(186)<<endl;
	cout << char(186) << " spotting you from range 18, special ops spot you from range 12. " <<char(186)<<endl;
	cout << char(186) << " upararalled long range with single shot                         " <<char(186) <<endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(200);
	for(int x = 0; x < 65; x++)
		cout << h;

	cout << char(188);
}
void Display::assualtInfo()//not included
{
	clearConsoleScreen(0,40);
	centerConsoleCursor(0, 40);

	char h[65] = {char(205)};
	cout << char(201);
	for(int x = 0; x < 65; x++)
		cout << h;

	cout << char(187) << endl;  
	cout << char(186) << " 100 hp, 50 ap, Machine gun : 20char(0), pistol 20               " << char(186)<< endl;
	cout << char(186) << " Range 12, dmg 12                                                " << char(186)<< endl;
	cout << char(186) << " *BONUS +75 ap defense                                           " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(200);
	for(int x = 0; x < 65; x++)
		cout << h;
	cout << char(188);
	
}
void Display::supportInfo()//not included
{
	clearConsoleScreen(0, 40);
	centerConsoleCursor(0, 40);
	
	char h[65] = {char(205)};
	cout << char(201);
	for(int x = 0; x < 65; x++)
		cout << h;
	cout << char(187) << endl;  
	cout << char(186) << "100 hp, 75 ap, Heavy Machine gun : 100char(0), pistol 20         " << char(186)<< endl;
	cout << char(186) << "Range 16, dmg 8                                                  " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(200);
	for(int x = 0; x < 65; x++)
		cout << h;
	cout << char(188);
}
void Display::medicInfo()//not included
{
	clearConsoleScreen(0, 40);
	centerConsoleCursor(0, 40);
	
	char h[65] = {char(205)};
	cout << char(201);
	for(int x = 0; x < 65; x++)
		cout << h;
	cout << char(187) << endl;
	cout << char(186) << "100 hp, 10 ap, rifle : 5char(0), pistol 20                       " << char(186)<< endl;
	cout << char(186) << "Range 1char(0), dmg 35                                           " << char(186)<< endl;
	cout << char(186) << " *BONUS heals over time                                          " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(200);
	for(int x = 0; x < 65; x++)
		cout << h;
	cout << char(188);
}
void Display::engineerInfo()//not included
{
	clearConsoleScreen(0, 40);
	centerConsoleCursor(0, 40);

	char h[65] = {char(205)};
	cout << char(201);
	for(int x = 0; x < 65; x++)
		cout << h;
	cout << char(187) << endl;
	cout << char(186) << "100 hp, 10 ap, shotgun: 25, pistol 20                            " << char(186)<< endl;
	cout << char(186) << "Range 5, dmg 100                                                 " << char(186)<< endl;
	cout << char(186) << " *BONUS repair vehicle over time(inside)                         " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(200);
	for(int x = 0; x < 65; x++)
		cout << h;
	cout << char(188);
	
}
void Display::anti_tankInfo()//not included
{
	clearConsoleScreen(0, 40);
	centerConsoleCursor(0, 40);

	char h[65] = {char(205)};
	cout << char(201);
	for(int x = 0; x < 65; x++)
		cout << h;
	cout << char(187) << endl;
	cout << char(186) << "100 hp, 85 ap, bazooka: 1char(0), pistol 20                      " << char(186)<< endl;
	cout << char(186) << "Range 14 (every distance -45 damage) dmg 600                     " << char(186)<< endl;
	cout << char(186) << "*BONUS 250 dmg 4 radius splash damage                            " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(200);
	for(int x = 0; x < 65; x++)
		cout << h;
	cout << char(188);
}

void Display::botNumMenu()//not included
{
	cout <<
		setw(20) << " Enter number of Bots you would like to pit against ";
	cin >> butNum;
}

void Display::centerConsoleCursor(int x, int y)
{
	HANDLE screen = GetStdHandle( STD_OUTPUT_HANDLE ); 
		COORD _ = { x, y }; SetConsoleCursorPosition( screen, _); 
}

void Display::clearConsoleScreen(int x, int y)
{
	HANDLE screen = GetStdHandle( STD_OUTPUT_HANDLE ); 
	DWORD NumberOfCharsWritten; 
	COORD _ = { x, y }; 
	FillConsoleOutputCharacter ( screen, ' ', 0xffff, _, &NumberOfCharsWritten ); 
	SetConsoleCursorPosition( screen, _); 
}

void Display::setConsoleColors(WORD color, WORD color2)
{
	HANDLE screen = GetStdHandle( STD_OUTPUT_HANDLE );
	SetConsoleTextAttribute(screen , color | color2);
}

void Display::setConsoleColor(WORD color)
{
	HANDLE screen = GetStdHandle( STD_OUTPUT_HANDLE );
	SetConsoleTextAttribute(screen , color);
}

void Display::setConsoleTextSize(int x, int y)
{
	HANDLE screen = GetStdHandle( STD_OUTPUT_HANDLE );
	//SetConsoleTextAttribute(screen , color);
	COORD _ = { x, y }; 

}

void Display::setConsoleSize()
{
	
	HANDLE hOut;
		CONSOLE_SCREEN_BUFFER_INFO SBInfo;
		COORD bufferSize;
		COORD windowSize;
		SMALL_RECT DisplayArea = {0, 0, 0, 0};
		int x;
		int y;
		int wX;
		int wY;

		hOut = GetStdHandle(STD_OUTPUT_HANDLE);
		GetConsoleScreenBufferInfo(hOut,&SBInfo);
		centerConsoleCursor( char(0), 0);
		
		x = 142;
		y = 81;

		bufferSize.X = x;
		bufferSize.Y = y;
		DisplayArea.Right = x - 1;
		DisplayArea.Bottom = y - 1;
			
		SetConsoleWindowInfo(hOut,TRUE, &DisplayArea);

		Sleep(50);
		clearConsoleScreen(char(0),0);
		centerConsoleCursor(char(0), 0);
		
		//cout << "WELCOME to MAD CHESS" << endl;

		SetConsoleScreenBufferSize(hOut,bufferSize);
		Sleep(50);
}

void Display::setTree() // 2
{
	 char obj[7][11] = {
			{char(0),   char(0),   char(0),   char(0),   char(0), char(char(178)), char(char(178)),   char(0),   char(0),   char(0),   char(0)},
			{char(0),   char(0),   char(0), char(char(178)), char(char(178)), char(char(178)), char(char(178)), char(char(178)), char(char(178)),   char(0),   char(0)},
			{char(0),   char(0), char(char(178)), char(char(178)), char(char(178)), char(char(178)), char(char(178)), char(char(178)), char(char(178)), char(char(178)),   char(0)},
			{char(0),   char(0),   char(0), char(char(178)), char(char(178)), char(char(178)), char(char(178)), char(char(178)), char(char(178)),   char(0),   char(0)},
			{char(0),   char(0),   char(0),   char(0), char(char(178)), char(219), char(219), char(char(178)),   char(0),   char(0),   char(0)},
			{char(0),   char(0),   char(0),   char(0),   char(0), char(219), char(219),   char(0),   char(0),   char(0),   char(0)},
			{char(0),   char(0),   char(0),   char(0),   char(0), char(219), char(219),   char(0),   char(0),   char(0),   char(0)}};

	for(int x = 0; x < 7; x++)
	{
		for(int y = 0; y < 11; y++)
			tree[x][y] = obj[x][y];	
	}
}

void Display::setRock() //7
{
	char obj[7][11] = {
		{   char(0),   char(0), char(219), char(219), char(219), char(219),   char(0),   char(0),   char(0),   char(0),   char(0)},
		{   char(0), char(char(221)), char(219), char(219), char(219), char(219), char(char(221)),   char(0),   char(0),   char(0),   char(0)},
		{   char(0), char(219), char(219), char(219), char(219), char(219), char(219), char(219),   char(0),   char(0),   char(0)},
		{   char(0), char(219), char(219), char(219), char(219), 219, 219, char(219), char(219),   char(0),   char(0)},
		{   char(0), char(219), char(219), char(219), char(219), 219, 219, char(219), char(219), char(219),   char(0)},
		{ char(219), char(219), char(219), char(219), char(219), char(219), char(219), char(219), char(219), char(219),   char(0)},
		{ char(219), char(219), char(219), char(219), char(219), char(219), char(219), char(219), char(219), char(219), char(219)}};

		for(int x = 0; x < 7; x++)
	{
		for(int y = 0; y < 11; y++)
			rock[x][y] = obj[x][y];	
	}
}

void Display::setGrass() ///9
{
	string showObj = "";
	char obj[7][11] = {
			{char(char(176)),   char(char(176)),   char(char(176)),   char(char(176)),   char(char(176)), char(char(176)), char(char(176)),   char(char(176)),   char(char(176)),  char(char(176)),   char(char(176))},
			{char(char(176)),   char(char(176)),   char(char(176)),   char(char(176)),   char(char(176)), char(char(176)), char(char(176)),   char(char(176)),   char(char(176)),  char(char(176)),   char(char(176))},
			{char(char(176)),   char(char(176)),   char(char(176)),   char(char(176)),   char(char(176)), char(char(176)), char(char(176)),   char(char(176)),   char(char(176)),  char(char(176)),   char(char(176))},
			{char(char(176)),   char(char(176)),   char(char(176)),   char(char(176)),   char(char(176)), char(char(176)), char(char(176)),   char(char(176)),   char(char(176)),  char(char(176)),   char(char(176))},
			{char(char(176)),   char(char(176)),   char(char(176)),   char(char(176)),   char(char(176)), char(char(176)), char(char(176)),   char(char(176)),   char(char(176)),  char(char(176)),   char(char(176))},
			{char(char(176)),   char(char(176)),   char(char(176)),   char(char(176)),   char(char(176)), char(char(176)), char(char(176)),   char(char(176)),   char(char(176)),  char(char(176)),   char(char(176))},
			{char(char(176)),   char(char(176)),   char(char(176)),   char(char(176)),   char(char(176)), char(char(176)), char(char(176)),   char(char(176)),   char(char(176)),  char(char(176)),   char(char(176))}};


	for(int x = 0; x < 7; x++)
	{
		for(int y = 0; y < 11; y++)
			grass[x][y] = obj[x][y];	
	}
}

void Display::setSnow() //4
{
	string showObj = "";
	char obj[7][11] = {
			{char(177),   char(177),    char(177),   char(177),   char(177),  char(177),  char(177),    char(177),   char(177),   char(177),    char(177)},
			{char(177),   char(177),    char(177),   char(177),   char(177),  char(177),  char(177),    char(177),   char(177),   char(177),    char(177)},
			{char(177),   char(177),    char(177),   char(177),   char(177),  char(177),  char(177),    char(177),   char(177),   char(177),    char(177)},
			{char(177),   char(177),    char(177),   char(177),   char(177),  char(177),  char(177),    char(177),   char(177),   char(177),    char(177)},
			{char(177),   char(177),    char(177),   char(177),   char(177),  char(177),  char(177),    char(177),   char(177),   char(177),    char(177)},
			{char(177),   char(177),    char(177),   char(177),   char(177),  char(177),  char(177),    char(177),   char(177),   char(177),    char(177)},
			{char(177),   char(177),    char(177),   char(177),   char(177),  char(177),  char(177),    char(177),   char(177),   char(177),    char(177)}};

	for(int x = 0; x < 7; x++)
	{
		for(int y = 0; y < 11; y++)
			snow[x][y] = obj[x][y];	
	}
}

void Display::setWater() //1
{
	string showObj = "";
	char obj[7][11] = {
			{char(176),   char(176),   char(176),   char(176),   char(176), char(176), char(176),   char(176),   char(176),  char(176),   char(176)},
			{char(176),   char(176),   char(176),   char(176),   char(176), char(176), char(176),   char(176),   char(176),  char(176),   char(176)},
			{char(176),   char(176),   char(176),   char(176),   char(176), char(176), char(176),   char(176),   char(176),  char(176),   char(176)},
			{char(176),   char(176),   char(176),   char(176),   char(176), char(176), char(176),   char(176),   char(176),  char(176),   char(176)},
			{char(176),   char(176),   char(176),   char(176),   char(176), char(176), char(176),   char(176),   char(176),  char(176),   char(176)},
			{char(176),   char(176),   char(176),   char(176),   char(176), char(176), char(176),   char(176),   char(176),  char(176),   char(176)},
			{char(176),   char(176),   char(176),   char(176),   char(176), char(176), char(176),   char(176),   char(176),  char(176),   char(176)}};

	for(int x = 0; x < 7; x++)
	{
		for(int y = 0; y < 11; y++)
			water[x][y] = obj[x][y];	
	}
}

void Display::setDirt() //3
{
	char obj[7][11] = {
			{char(176),   char(176),   char(176),   char(176),   char(176), char(176), char(176),   char(176),   char(176),  char(176),   char(176)},
			{char(176),   char(176),   char(176),   char(176),   char(176), char(176), char(176),   char(176),   char(176),  char(176),   char(176)},
			{char(176),   char(176),   char(176),   char(176),   char(176), char(176), char(176),   char(176),   char(176),  char(176),   char(176)},
			{char(176),   char(176),   char(176),   char(176),   char(176), char(176), char(176),   char(176),   char(176),  char(176),   char(176)},
			{char(176),   char(176),   char(176),   char(176),   char(176), char(176), char(176),   char(176),   char(176),  char(176),   char(176)},
			{char(176),   char(176),   char(176),   char(176),   char(176), char(176), char(176),   char(176),   char(176),  char(176),   char(176)},
			{char(176),   char(176),   char(176),   char(176),   char(176), char(176), char(176),   char(176),   char(176),  char(176),   char(176)}};

	for(int x = 0; x < 7; x++)
	{
		for(int y = 0; y < 11; y++)
			dirt[x][y] = obj[x][y];	
	}	
}

void Display::setHero() //10
{
	char obj[7][11] = {
			{char(0),   char(0),   char(0),   char(0),   char(0),   char(0),   char(0),   char(0),   char(0),   char(0),   char(0)},
			{char(0),   char(0),   char(0),   char(0),   char(0),   2,   char(0),   char(0),   char(0),   char(0),   char(0)},
			{char(0),   char(0),   char(0),   char(0), char(220), char(220), char(222),   char(0),   char(0),   char(0),   char(0)},
			{char(0),   char(0),   char(0),   char(0), char(221), 219, char(223),   char(0),   char(0),   char(0),   char(0)},
			{char(0),   char(0),   char(0),   char(0),   char(0), 219, char(220),   char(0),   char(0),   char(0),   char(0)},
			{char(0),   char(0),   char(0),   char(0), char(220), char(221), char(222),   char(0),   char(0),   char(0),   char(0)},
			{char(0),   char(0),   char(0),   char(0),   char(0),   char(0),   char(0),   char(0),   char(0),   char(0),   char(0)}};

	for(int x = 0; x < 7; x++)
	{
		for(int y = 0; y < 11; y++)
			hero[x][y] = obj[x][y];	
	}

	
}

void Display::setZombie() //11
{
	char obj[7][11] = {
			{char(0),   char(0),   char(0),   char(0),   char(0),   char(0),   char(0),   char(0),   char(0),   char(0),   char(0)},
			{char(0),   char(0),   char(0),   char(0),   char(0),   char(1),   char(0),   char(0),   char(0),   char(0),   char(0)},
			{char(0),   char(0),   char(0),   char(0), char(220), char(220), char(222),   char(0),   char(0),   char(0),   char(0)},
			{char(0),   char(0),   char(0),   char(0), char(221), char(219), char(223),   char(0),   char(0),   char(0),   char(0)},
			{char(0),   char(0),   char(0),   char(0),   char(0), char(219), char(220),   char(0),   char(0),   char(0),   char(0)},
			{char(0),   char(0),   char(0),   char(0), char(220), char(221), char(222),   char(0),   char(0),   char(0),   char(0)},
			{char(0),   char(0),   char(0),   char(0),   char(0),   char(0),   char(0),   char(0),   char(0),   char(0),   char(0)}};

	for(int x = 0; x < 7; x++)
	{
		for(int y = 0; y < 11; y++)
			zombie[x][y] = obj[x][y];	
	}
	
}

void Display::setMonster() //12
{
	string showObj = "";
	char obj[7][11] = {
			{char(0),   char(0),   char(0),   char(0),   char(0), char(178), char(178),   char(0),   char(0),   char(0),   char(0)},
			{char(0),   char(0), char(178), char(178), char(178), char(178), char(178), char(178), char(178), char(178),   char(0)},
			{char(0), char(178), char(178), char(178), char(178), char(178), char(178), char(178), char(178), char(178),  char(178)},
			{char(0),   char(0), char(178), char(178), char(178), char(178), char(178), char(178), char(178), char(178),   char(0)},
			{char(0),   char(0),   char(0),   char(0), char(178), char(178), char(178), char(178),   char(0),   char(0),   char(0)},
			{char(0),   char(0),   char(0),   char(0),   char(0), char(178), char(178),   char(0),   char(0),   char(0),   char(0)},
			{char(0),   char(0),   char(0),   char(0),   char(0), char(178), char(178),   char(0),   char(0),   char(0),   char(0)}};

	for(int x = 0; x < 7; x++)
	{
		for(int y = 0; y < 11; y++)
			monster[x][y] = obj[x][y];	
	}	
}
void Display::setDeamon() //13
{
	char obj[7][11] = {
			{char(0),   char(0),   char(0),   char(0),   char(0), char(178), char(178),   char(0),   char(0),   char(0),   char(0)},
			{char(0),   char(0), char(178), char(178), char(178), char(178), char(178), char(178), char(178), char(178),   char(0)},
			{char(0), char(178), char(178), char(178), char(178), char(178), char(178), char(178), char(178), char(178),  char(178)},
			{char(0),   char(0), char(178), char(178), char(178), char(178), char(178), char(178), char(178), char(178),   char(0)},
			{char(0),   char(0),   char(0),   char(0), char(178), char(178), char(178), char(178),   char(0),   char(0),   char(0)},
			{char(0),   char(0),   char(0),   char(0),   char(0), char(178), char(178),   char(0),   char(0),   char(0),   char(0)},
			{char(0),   char(0),   char(0),   char(0),   char(0), char(178), char(178),   char(0),   char(0),   char(0),   char(0)}};

	for(int x = 0; x < 7; x++)
	{
		for(int y = 0; y < 11; y++)
			deamon[x][y] = obj[x][y];	
	}
}
 

void Display::setHealth_Symbol()
{
	char obj[7][11] = {
			{  char(0),     char(0),      char(0),   char(222),   char(219),  char(219),  char(219),    char(221),     char(0),     char(0),      char(0)},
			{  char(0),     char(0),      char(0),   char(222),   char(219),  char(219),  char(219),    char(221),     char(0),     char(0),      char(0)},
			{char(219),   char(219),    char(219),   char(219),   char(219),  char(219),  char(219),    char(219),   char(219),   char(219),    char(219)},
			{char(219),   char(219),    char(219),   char(219),   char(219),  char(219),  char(219),    char(219),   char(219),   char(219),    char(219)},
			{char(219),   char(219),    char(219),   char(219),   char(219),  char(219),  char(219),    char(219),   char(219),   char(219),    char(219)},
			{  char(0),     char(0),      char(0),   char(222),   char(219),  char(219),  char(219),    char(221),     char(0),     char(0),      char(0)},
			{  char(0),		char(0),      char(0),   char(222),   char(219),  char(219),  char(219),    char(221),     char(0),     char(0),      char(0)}};

	for(int x = 0; x < 7; x++)
	{
		for(int y = 0; y < 11; y++)
			health[x][y] = obj[x][y];	
	}
}

void Display::setArmor_Symbol()
{

	char obj[7][11] = {
			{char(219),   char(219),    char(219),   char(219),   char(219),  char(219),  char(219),    char(219),   char(219),   char(219),    char(219)},
			{char(219),   char(219),    char(219),   char(219),   char(219),  char(219),  char(219),    char(219),   char(219),   char(219),    char(219)},
			{char(177),   char(219),    char(219),   char(219),   char(219),  char(219),  char(219),    char(219),   char(219),   char(219),    char(177)},
			{char(177),   char(219),    char(219),   char(219),   char(219),  char(219),  char(219),    char(219),   char(219),   char(219),    char(177)},
			{char(177),   char(177),    char(219),   char(219),   char(219),  char(219),  char(219),    char(219),   char(219),   char(177),    char(177)},
			{char(177),   char(177),    char(177),   char(219),   char(219),  char(219),  char(219),    char(219),   char(177),   char(177),    char(177)},
			{char(177),   char(177),    char(177),   char(177),   char(219),  char(219),  char(219),    char(177),   char(177),   char(177),    char(177)}};

	for(int x = 0; x < 7; x++)
	{
		for(int y = 0; y < 11; y++)
			armor[x][y] = obj[x][y];	
	}
}

void Display::setBullet()
{

	char obj[7][11] = {
			{char(219),   char(219),    char(219),   char(219),   char(219),  char(219),  char(219),    char(219),   char(219),   char(219),    char(219)},
			{char(219),   char(219),    char(219),   char(219),   char(219),  char(219),  char(219),    char(219),   char(219),   char(219),    char(219)},
			{char(177),   char(219),    char(219),   char(219),   char(219),  char(219),  char(219),    char(219),   char(219),   char(219),    char(177)},
			{char(177),   char(219),    char(219),   char(219),   char(219),  char(219),  char(219),    char(219),   char(219),   char(219),    char(177)},
			{char(177),   char(177),    char(219),   char(219),   char(219),  char(219),  char(219),    char(219),   char(219),   char(177),    char(177)},
			{char(177),   char(177),    char(177),   char(219),   char(219),  char(219),  char(219),    char(219),   char(177),   char(177),    char(177)},
			{char(177),   char(177),    char(177),   char(177),   char(219),  char(219),  char(219),    char(177),   char(177),   char(177),    char(177)}};

	for(int x = 0; x < 7; x++)
	{
		for(int y = 0; y < 11; y++)
			armor[x][y] = obj[x][y];	
	}
}

void Display::setHud(Player& p1, Inventory& invent)
{
	setConsoleColors(WHITE_2, EMPTY);

	centerConsoleCursor( 1, 1);
	cout << char(201);
	centerConsoleCursor( 1, 79);
	cout << char(200);
	

	for(int x = 0; x < 11; x++)
	{
		centerConsoleCursor( x + 114, 9);
		cout << char(205);
		centerConsoleCursor( x + 114, 17);
		cout << char(205);
	}

	for(int x = 0; x < 78; x++)
	{
		centerConsoleCursor( 113, x + 2);
		cout << char(186);
	}

	for(int x = 0; x < 123; x++)
	{
		centerConsoleCursor( x + 2, 1);
		cout << char(205);
		centerConsoleCursor( x + 2, 79);
		cout << char(205);
		
	}

	for(int x = 0; x < 77; x++)
	{
		centerConsoleCursor( 1, x + 2);
		cout << char(186);

		centerConsoleCursor( 125, x + 2);
		cout << char(186);
		
	}
	centerConsoleCursor(125, 9);
	cout << char(185);

	centerConsoleCursor(125, 17);
	cout << char(185);

	centerConsoleCursor(113, 79);
	cout << char(202);

	centerConsoleCursor(113, 1);
	cout << char(203);

	centerConsoleCursor(113, 9);
	cout << char(204);

	centerConsoleCursor(113, 17);
	cout << char(204);

	centerConsoleCursor(125, 1);
	cout << char(187);

	centerConsoleCursor(125, 79);
	cout << char(188);

	setConsoleColors(RED, B_WHITE_2);
	for(int a = 0; a < 7; a++)
	{ centerConsoleCursor(114, a + 2);
		for(int b = 0; b < 11; b++)
			cout << health[a][b];
		cout << endl;
	}

	setConsoleColors(WHITE_2, B_RED);
	centerConsoleCursor(117, 5);
	cout << "HEALTH";
	centerConsoleCursor(118, 6);
	setConsoleTextSize(4 ,4);
	cout << p1.getCurHp();


	setConsoleColors(WATER, B_WHITE_2);
	for(int a = 0; a < 7; a++)
	{ centerConsoleCursor(114, a + 10);
		for(int b = 0; b < 11; b++)
			cout << armor[a][b];
		cout << endl;
	}

	setConsoleColors(WHITE_2, B_WATER);
	centerConsoleCursor(117, 13);
	cout << "ARMOR";
	setConsoleTextSize(4 ,4);
	centerConsoleCursor(118, 14);
	cout << p1.getArmor();

	setConsoleColors(WHITE_2, B_WATER);
	centerConsoleCursor(117, 21);
	cout << "WEAPON";
	setConsoleTextSize(4 ,4);
	centerConsoleCursor(118, 22);
	cout << p1.getCurWep().getName();

	setConsoleColors(WHITE_2, EMPTY);
	centerConsoleCursor(115, 37);
	cout << "INVENTORY";
	list<Item*>::iterator inventoryIter; // inventory iterator
	//Prints out the items in the hud
	int xCoord = 116;
	int yCoord = 39;

	for(inventoryIter = invent.getInventory().begin(); inventoryIter != invent.getInventory().end(); inventoryIter++)
	{
		centerConsoleCursor(xCoord, yCoord);
		cout << (*inventoryIter)->getName();  
		centerConsoleCursor(xCoord, yCoord + 2);
		cout << (*inventoryIter)->getNumItems() << endl;
		yCoord += 6;
	}
}

bool Display::getStart()
{
	return start;
}

int Display::getCharacterNum()
{
	return charNum;
}

void Display::checkMap(int x, int y, int value)
{
	map.updateMap(x,y, value, lvlSel);
}

void Display::getBackground(int x)
{
	backgroundNum = x;
}

void Display::displayBattleScreen(int pDmg, int bDmg, Player& p1, Bot& b1)
{
	clearConsoleScreen(0, 40);
	centerConsoleCursor(0, 40);
	setConsoleColors(WHITE_2, EMPTY);
	char h[65] = {char(205)};
	cout << char(201);
	for(int x = 0; x < 65; x++)
		cout << h;
	cout << char(187) << endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(186) << p1.getName() <<"'s HEALTH: " <<  p1.getCurHp() << " " << "DAMAGE INFLICTING:                          " << pDmg << " " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(186) << b1.getName() <<"'s HEALTH: " <<  b1.getCurHp() << " " << "DAMAGE INFLICTING:                          " << bDmg << " " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(186) << "                                                                 " << char(186)<< endl;
	cout << char(200);
	for(int x = 0; x < 65; x++)
		cout << h;
	cout << char(188);

	if(b1.getCurHp() < 1)
	{
		clearConsoleScreen(0, 40);
		centerConsoleCursor(0, 40);
		char h[65] = {char(205)};
		cout << char(201);
		for(int x = 0; x < 65; x++)
			cout << h;
		cout << char(187) << endl;
		cout << char(186) << "                                                                 " << char(186)<< endl;
		cout << char(186) << "                                                                 " << char(186)<< endl;
		cout << char(186) << "           YOU HAVE KILLED THE " << b1.getName() << "        " << char(186)<< endl;
		cout << char(186) << "                                                                 " << char(186)<< endl;
		cout << char(186) << b1.getName() <<"'s HEALTH: " <<  b1.getCurHp() << " " << "DAMAGE INFLICTING: " << bDmg << " " << char(186)<< endl;
		cout << char(186) << "                                                                 " << char(186)<< endl;
		cout << char(186) << "                                                                 " << char(186)<< endl;
		cout << char(200);
		for(int x = 0; x < 65; x++)
			cout << h;
		cout << char(188);
	}
}

void Display::displayScreen(int i, int j, Player& p1, Inventory& invent)
{
	setWater();
	setTree();
	setDirt();
	setSnow();
	setGrass();
	setWater();
	setRock();
	setHero();
	setHealth_Symbol();
	setArmor_Symbol();
	setHud(p1, invent);
	setZombie();
	setDeamon();
	setMonster();
	setBullet();
	int m = 10;
	int n = 11;

	int count = 2 ;
	for(int y = j; y < j + n; y++)
	{
		for(int a = 0; a < 7; a++)
		{
			centerConsoleCursor(2, count++);
			for(int x = i; x < i + m; x++)
			{
				for(int b = 0; b < 11; b++)
				{ 
					if(map.getMap(x, y, lvlSel) == 1)
					{
						setConsoleColors(WATER, B_DEEPWATER);
						cout << water[a][b];
					}
					if(map.getMap(x, y , lvlSel) == 2)
					{
						setConsoleColors(LEAF, B_GRASS);
						cout << tree[a][b];
					}
					if(map.getMap(x, y, lvlSel) == 3)
					{
						setConsoleColors(BROWN, B_BROWN);
						cout << dirt[a][b];
					}
					if(map.getMap(x, y, lvlSel) == 4)
					{
						setConsoleColors(WHITE, WHITE_2);
						cout << snow[a][b];
					}
					if(map.getMap(x, y, lvlSel) == 5)
					{
						setConsoleColors(GRASS, B_GRASS);
						cout << grass[a][b];
					}
					if(map.getMap(x, y, lvlSel) == 6)
					{
							setConsoleColors(INTENSE, B_BROWN);
							cout << rock[a][b];
					}
					if(map.getMap(x, y, lvlSel) == 10)
					{
						if(backgroundNum == 3)
							setConsoleColors(WHITE_2, B_BROWN);
						else if(backgroundNum == 4)
							setConsoleColors(WHITE_2, EMPTY);
						else if(backgroundNum == 5)
							setConsoleColors(WHITE_2, B_GRASS);
						else if(backgroundNum == 6)
							setConsoleColors(WHITE_2, EMPTY);
						else if(backgroundNum == 15)
							setConsoleColors(WHITE_2, B_BROWN);
						cout << hero[a][b];
					}
					if(map.getMap(x, y, lvlSel) == 12)
					{
						
						setConsoleColors(WHITE_2, EMPTY);
						cout << zombie[a][b];
					}
					if(map.getMap(x, y, lvlSel) == 13)
					{
						setConsoleColors(WHITE_2, EMPTY);
						cout << monster[a][b];
					}
					if(map.getMap(x, y, lvlSel) == 14)
					{
						setConsoleColors(WHITE_2, EMPTY);
						cout << deamon[a][b];
					}
					//run into ammo
					if(map.getMap(x, y, lvlSel) == 15)
					{
						setConsoleColors(BROWN, B_BROWN);
						cout << dirt[a][b];
					}
					//run into health
					if(map.getMap(x, y, lvlSel) == 16)
					{
						setConsoleColors(RED, B_WHITE_2);
						cout << health[a][b];
					
					}
					//run into armor
					if(map.getMap(x, y, lvlSel) == 17)
					{
						setConsoleColors(WATER, B_WHITE_2);
						cout << armor[a][b];
					}

				}//end b loop
			} //end x loop
			cout << endl;
		}//end a loop
		
	}// end y loop

	//inventory
}