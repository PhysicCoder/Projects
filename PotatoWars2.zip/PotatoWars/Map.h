#ifndef MAP_H
#define MAP_H

class Map
{
public:
	Map();
	void map_1();
	void map_2();
	void map_3();
	void map_4();
	void updateMap(int x, int y, int value, int mapNum);
	int getMap(int x, int y, int mapNum);
private:
	int map1[32][32];
	int map2[32][32];
	int map3[32][32];
	int map4[32][32];
};

#endif