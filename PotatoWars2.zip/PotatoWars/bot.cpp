#include "bot.h"

Bot::Bot() {}

Bot::Bot(string name, Weapon primeWep, int dmg, int armor, int x, int y)
{
	this->name = name;
	this->primWep = primWep;
	this->armor = armor;
	this->dmg = dmg;
	this->x = x;
	this->y = y;
}