#include "Character.h"

Character::Character()
{
	this->name = "Default";
	Weapon primWep;
	this->primWep = primWep;
	this->dmg = 0;
	this->armor = 0;
	this->maxArmor = 0;
	this->direction = direction;
	this->x = x;
	this->y = y;
	Weapon wep("Pistol", 20, 8, 10);
	this->secWep = wep;
	Weapon vehwep;
	this->vehWep = vehWep;
	this->curWep = secWep; 
	curHp = 100;
	direction = N;
	shooting = false;
	driving = false;
	status = false;
	bulletID = 1;
}

Character::Character(string name, Weapon primWep, int dmg, int armor, int x, int y)
{
	this->name = name;
	this->primWep = primWep;
	this->dmg = dmg;
	this->maxArmor = armor;
	this->armor = armor;
	this->x = x;
	this->y = y;
	Weapon secWep("Pistol", 20, 8, 10);
	this->secWep = secWep;
	Weapon vehwep;
	this->vehWep = vehWep;
	this->curWep = secWep; 
	curHp = 100;
	direction = N;
	shooting = false;
	driving = false;
	status = false;
	bulletID = 1;
}

Character::~Character()
{
	for(bulletsIter = bullets.begin(); bulletsIter != bullets.end(); bulletsIter++)
	{
		delete *bulletsIter;
	}
}

int Character::getDmg()
{
	return dmg;
}

int Character::getPosX()
{
	return x;
}
int Character::getPosY()
{
	return y;
}
void Character::setPosition(int x, int y)
{
	this->x = x;
	this->y = y;
}
int Character::getDirection()
{
	return direction;
}
void Character::setDiection(int direction)
{
	//dir = direction;
}
void Character::setName(string name)
{
	this->name = name;
}
string Character::getName()
{
	return name;
}
Weapon& Character::getPrimWep()
{
	return primWep;
}
Weapon& Character::getSecWep()
{
	return secWep;
}
Weapon& Character::getVehWep()
{
	return vehWep;
}
Weapon& Character::getCurWep()
{
	return curWep;
}
void Character::changeWep()
{
	
}

int Character::getMaxArmor()
{
	return maxArmor;
}

int Character::getArmor()
{
	return armor;
}

void Character::setArmor(int armor)
{
	this->armor = armor;
}
int Character::getmaxHp()
{
	return maxHp;
}
int Character::getCurHp()
{
	return curHp;
}
void Character::setCurHp(int hp)
{
	this->curHp = hp;
}
void Character::shoot()
{
	bullets.push_back(new Bullet(bulletID, curWep.getDmg(), curWep.getRange(), direction, 
					  x, y)); 

	bulletID++;
}

/*Vehicle Character::getVehicle()
{
	return vehicle;
}*/

void Character::setStatus(bool status)
{
	this->status = status;
}
bool Character::getStatus()
{
	return status;
}
bool Character::getDriving()
{
	return driving;
}