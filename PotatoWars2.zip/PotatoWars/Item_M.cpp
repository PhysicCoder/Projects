#include "Item.h"

Item::Item(string name, int numItems, int id)
{
	this->name = name;
	this->numItems = numItems;
}
string Item::getName()
{
	return name;
}

int Item::getId()
{
	return id;
}

int Item::getNumItems()
{
	return numItems;
}

void Item::setNumItems(int numItems)
{
	this->numItems = numItems;
}