#include "keyBoard.h"

KeyBoard::KeyBoard() {}

void KeyBoard::listen()
{
	keyPressed = _getch();
}

int KeyBoard::getPressed()
{
	return keyPressed;
}