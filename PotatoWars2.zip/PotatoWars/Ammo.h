#ifndef AMMO_H
#define AMMO_H

#include "Item.h"
#include "player.h"

class Ammo : public Item
{
public:
	Ammo(string name, int numItems, int id, int ammoRefill);
	virtual void useItem(Character p1);
private:
	int ammoRefill;
};
#endif