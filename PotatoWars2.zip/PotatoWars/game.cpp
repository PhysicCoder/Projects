#include "game.h"


Game::Game() 
{
	lvlSel = NULL;
	pickUp = false;
}


void Game::startGame()
{
	display.setConsoleSize();
	display.reset();
    int a = 1;

	do
	{
		display.centerConsoleCursor(0, 20);
		display.displayMenu();
		lvlSel = display.getLvlNum();
		
	}while(!display.getStart());
	
	
}
void Game::loadLevel()
{
	if(lvlSel == ROCK)
		map.map_1();
	else if(lvlSel == GRASS)
		map.map_2();
	else if(lvlSel == ISLAND)
		map.map_3();
	else 
		map.map_4();
}

void Game::playGame()
{ 


	if(display.getStart())
	{
		
		Weapon weapon("Machine gun", 200, 14, 10);
		Player player("SPECIAL OPS",weapon, 50, 25, 5, 5);
		Inventory invent;
		this->player = player;
		player.setStatus(true);
		Bot monster("MONSTER", weapon, 25, 75, 7, 7);
		this->monster = monster;
		monster.setStatus(true);
		X = player.getPosX();
		Y = player.getPosY();
		int hp = player.getCurHp();
		int ap = player.getArmor();
		Bullet bullet(1, 10, 12, 1, X, Y);  
		map.updateMap(monster.getPosX(), monster.getPosY(), 13, lvlSel);
		
		player.setDiection(1);
		
		int temp;
		int temp2;
		int temp3 = 5;
		int bT;
		int bT2;
		int bT3;
		int posX;
		int posY;
		int pX = 5;
		int pY = 5;
		int bX = 0;
		int bY = 0;
		int bX2;
		int bY2;
		bool move = false;
		int count = 0;

		bX = bullet.getPosX();
		bY = bullet.getPosY();
	
		
	
		map.updateMap(X, Y, 10, lvlSel);

		//checks the map
		for(int y = 0; y < 32; y++)
		{
				for(int x = 0; x < 32; x++){
					display.checkMap(x, y, map.getMap(x,y, lvlSel));
			}
		}
			display.displayScreen(X - 4, Y - 4, player, invent);
		do
		{
			keyboard.listen();
			Sleep(1);
		
			switch(keyboard.getPressed())
			{
			case keyboard.KEY_UP:
				if(collision(X, Y - 1, invent, player, monster))
				{
					//do nothing
				}
				else
				{
					temp = map.getMap(X, Y, lvlSel);
					if(!move)
					{
						temp2 = map.getMap(X, Y - 1, lvlSel);
						posX = X;
						posY = Y - 1;
						map.updateMap(pX, pY, temp3, lvlSel);
						move = true;
						display.getBackground(temp2);
					}
					else
					{
						temp3 = map.getMap(X, Y - 1, lvlSel);
						pX = X;
						pY = Y - 1;
						map.updateMap(posX, posY, temp2, lvlSel);
						move = false;
						display.getBackground(temp3);
					}
				

					map.updateMap(X, Y - 1, temp, lvlSel);
					player.setPosition(X,Y - 1);
				}
				break;
			case keyboard.KEY_DOWN:
				if(collision(X, Y + 1, invent, player, monster))
				{
					//do nothing
				}
				else
				{
					temp = map.getMap(X, Y, lvlSel);
					if(!move)
					{
						temp2 = map.getMap(X, Y + 1, lvlSel);
						posX = X;
						posY = Y + 1;
						map.updateMap(pX, pY, temp3, lvlSel);
						move = true;
						display.getBackground(temp2);
					}
					else
					{
						temp3 = map.getMap(X, Y + 1, lvlSel);
						pX = X;
						pY = Y + 1;
						map.updateMap(posX, posY, temp2, lvlSel);
						move = false;
						display.getBackground(temp3);
					}
				

					map.updateMap(X, Y + 1, temp, lvlSel);
					player.setPosition(X,Y + 1);
				}
				break;
			case keyboard.KEY_LEFT:
				if(collision(X - 1, Y, invent, player, monster))
				{
					//do nothing
				}
				else
				{
					temp = map.getMap(X, Y, lvlSel);
					if(!move)
					{
						temp2 = map.getMap(X - 1, Y, lvlSel);
						posX = X - 1;
						posY = Y;
						map.updateMap(pX, pY, temp3, lvlSel);
						move = true;
						display.getBackground(temp2);
					}
					else
					{
						temp3 = map.getMap(X - 1, Y, lvlSel);
						pX = X - 1;
						pY = Y;
						map.updateMap(posX, posY, temp2, lvlSel);
						move = false;
						display.getBackground(temp3);
					}
				
					map.updateMap(X - 1, Y, temp, lvlSel);
					player.setPosition(X - 1,Y);
				}
				break;
			case keyboard.KEY_RIGHT:
				if(collision(X + 1, Y, invent, player, monster))
				{
					//do nothing
				}
				else
				{
					temp = map.getMap(X, Y, lvlSel);
					if(!move)
					{
						temp2 = map.getMap(X + 1, Y, lvlSel);
						posX = X + 1;
						posY = Y;
						map.updateMap(pX, pY, temp3, lvlSel);
						move = true;
						display.getBackground(temp2);
					}
					else
					{
						temp3 = map.getMap(X + 1, Y, lvlSel);
						pX = X + 1;
						pY = Y;
						map.updateMap(posX, posY, temp2, lvlSel);
						move = false;
						display.getBackground(temp3);
					}
				

					map.updateMap(X + 1, Y, temp, lvlSel);
					player.setPosition(X + 1,Y);
				}
				break;
		/*	case keyboard.KEY_SPACE_BAR: //since no bullets are implement the shooting code excluded also from the main code.
				//count = 0;
			//	player.shoot();
				
				//do
				//{
					++count;
					display.centerConsoleCursor(X + 48 + count, Y + 28);
					cout << "BULLET";
					Sleep(50);
					
					
				//}while(count < 50);

				//map.updateMap(X + count, Y, bT, lvlSel);
				//bullet.setPosition(X + 1,Y);
				break;*/
			case keyboard.KEY_I: //I for inventory
					display.inventoryMenu(player, invent);
				break;
			}//end of switch
			
			player.getCurHp();
			player.getArmor();
			X = player.getPosX();
			Y = player.getPosY();
			bX = bullet.getPosX();
			bY = bullet.getPosY();


			for(int y = 0; y < 32; y++)
			{
				for(int x = 0; x < 32; x++)
				{
					display.checkMap(x, y, map.getMap(x,y, lvlSel));
				}
			}
			display.displayScreen(X - 4, Y - 4, player, invent);
			//Sleep(25);
		}while(player.getStatus());
	}
}

bool Game::collision(int x, int y, Inventory& invent, Player& p1, Bot& b1)
{
	bool blocked = false;
	int object = map.getMap(x, y, lvlSel);

	switch(object)
	{
	case 1:
		blocked = true;
		break;
	case 2:
		blocked = true;
		break;
	case 6:
		blocked = true;
		break;
	case 7:
		blocked = true;
		break;
	case 11:
		blocked = true;
		break;
	case 12:
		blocked = true;
		break;
	case 13:
		attack(p1, b1);
		blocked = true;
		break;
	case 14:
		blocked = true;
		break;
	/*case 15: A bullet item, we havn't had time to make a bullet 
		/* checks if that item is already in the inventory if it is then incremements that
		items numItems */
	/*	if (invent.findItem("ammo") == 1)
		{
			invent.getItem("ammo").setNumItems(invent.getItem("ammo").getNumItems()+1);
		}
		//If it is not then it adds the item to the inventory list
		else
		{
			invent.addItem(new Ammo("ammo", 1, invent.getNextId(), 10));
		}

		break;*/
	case 16:
		if (invent.findItem("healthPack") == 1)
		{
			invent.getItem("healthPack").setNumItems(invent.getItem("healthPack").getNumItems()+1);
			map.updateMap(x, y, 5, lvlSel);
		}
		else
		{
			invent.addItem(new HealthPack("healthPack", 1, invent.getNextId(), 20));
			map.updateMap(x, y, 5, lvlSel);
		}

		break;
	case 17:
		if (invent.findItem("armor") == 1)
		{
			invent.getItem("armor").setNumItems(invent.getItem("armor").getNumItems()+1);
			map.updateMap(x, y, 5, lvlSel);
		}
		else
		{
			invent.addItem(new Armor("armor", 1, invent.getNextId(), 20));
			map.updateMap(x, y, 5, lvlSel);
		}

		break;
	default:
		blocked = false;
	}

	return blocked;
}

void Game::attack(Player& p1, Bot& b1)
{
	int p1Damage;
	int b1Damage;
	bool dead = false;
	do
	{
		srand(time(NULL));

		p1Damage = rand()%p1.getDmg();
		b1Damage = rand()%b1.getDmg();


		p1.setCurHp(p1.getCurHp() - b1Damage);
		b1.setCurHp(b1.getCurHp() - p1Damage);

		display.displayBattleScreen(p1Damage, b1Damage, p1, b1);
		Sleep(1200);

		if(p1.getCurHp() < 1)
		{
			p1.setStatus(false);
			dead = true;
		}
		else if(b1.getCurHp() < 1)
			dead = true;
	}while(!dead);
}
