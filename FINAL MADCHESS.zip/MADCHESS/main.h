#include "standard.h"

HANDLE stdOut = GetStdHandle(STD_OUTPUT_HANDLE); // to able to manipulate colors