#include "main.h"
#include "gamePlay.h"
using namespace GamePlay;

int main()
{
	Play start;
	start.setCurrentBoard();
	start.action();
	system("pause");
	return 0;
}


	