struct player1  //player info, player's history(units)
{
	enum chessPieces {PAWN = 1, KNIGHT, BISHOP, ROOK, QUEEN, KING}; //ChessPieces
};

struct player2 //player info, player's history(units)
{
	enum chessPieces {PAWN = 11, KNIGHT, BISHOP, ROOK, QUEEN, KING}; //ChessPieces
};

enum emptySquare EMPTY;

player1 p1;
player2 p2;	

