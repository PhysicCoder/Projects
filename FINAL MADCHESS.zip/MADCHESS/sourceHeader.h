#include <stdlib.h>
#include <iostream>
#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <string>
#include <iomanip>
#include <windows.h>

using namespace std;


