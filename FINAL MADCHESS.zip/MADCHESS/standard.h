#include <stdlib.h>
#include <iostream>
#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <string>
#include <time.h>
#include <iomanip>
#include <windows.h>

using namespace std;

//HANDLE stdOut = GetStdHandle(STD_OUTPUT_HANDLE); // to able to manipulate colors